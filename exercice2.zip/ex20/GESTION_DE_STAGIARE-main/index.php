<?php
    header("location:pages/filieres.php");
?>